import { app, BrowserWindow, shell, ipcMain } from "electron";
import { isDev, ipcMainHandle } from "./util.js";
import { getStaticData, pullResources, buildFullItReport } from "./resourceManager.js";
import { getPreloadPath, getUIPath } from "./pathResolver.js";

app.on("ready", () => {
  const mainWindow = new BrowserWindow({
    title: "RC System Dashboard",
    webPreferences: {
      preload: getPreloadPath(),
    },
  });

  if (isDev()) {
    mainWindow.loadURL("http://localhost:5123/");
  } else {
    mainWindow.loadFile(getUIPath());
  }

  pullResources(mainWindow);

  ipcMainHandle("getStaticData", () => {
    return getStaticData();
  });

  ipcMain.handle("sendToIT", async (_event, { data, stats }) => {
    try {
      const report = buildFullItReport(data, stats);
      const encoded = encodeURIComponent(report);

      const mailto = `mailto:helpdesk@roanoke.edu?subject=RC System Diagnostic Report&body=${encoded}`;

      console.log("Opening mailto:", mailto);

      await shell.openExternal(mailto);
    } catch (err) {
      console.error("Failed to open mail client:", err);
    }
  });
});
