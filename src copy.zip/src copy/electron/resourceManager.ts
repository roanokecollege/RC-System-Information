import si from "systeminformation";
import fs from "fs";
import os from "os";
import path from "path";
import { BrowserWindow } from "electron/main";
import { ipcWebContentsSend } from "./util.js";

const POLLING_INTERVAL = 1000;

/* =========================
   LIVE RESOURCE LOOP
========================= */

export function pullResources(mainWindow: BrowserWindow) {
  const interval = setInterval(async () => {
    if (mainWindow.isDestroyed()) {
      clearInterval(interval);
      return;
    }

    const [cpu, mem, fsData, net] = await Promise.all([
      si.currentLoad(),
      si.mem(),
      si.fsSize(),
      si.networkStats(),
    ]);

    const cpuUsage = cpu.currentLoad / 100;
    const ramUsage = mem.used / mem.total;

    const disk = fsData[0];
    const storageUsage = disk ? disk.use / 100 : 0;

    const netStats = net[0];

    ipcWebContentsSend("statistics", mainWindow.webContents, {
      cpuUsage,
      ramUsage,
      storageUsage,
      netUp: netStats?.tx_sec ?? 0,
      netDown: netStats?.rx_sec ?? 0,
    });
  }, POLLING_INTERVAL);
}

/* =========================
   STATIC DATA
========================= */

export async function getStaticData() {
  const [disk, mem, cpu, osInfo, systemInfo, time] = await Promise.all([
    si.fsSize(),
    si.mem(),
    si.cpu(),
    si.osInfo(),
    si.system(),
    si.time(),
  ]);

  const totalStorage = disk[0]?.size
    ? Math.floor(disk[0].size / 1_000_000_000)
    : 0;

  const totalMemoryGB = Math.floor(mem.total / 1_000_000_000);

  const cpuModel = cpu.manufacturer + " " + cpu.brand;

  const computerName = os.hostname();

  const { localIp, macAddress, publicIp } = await getFullNetworkData();

  const infoFiles = getInfoFileData();

  const { manufacturer, model, serial } = systemInfo;

  return {
    /* =========================
       EXISTING DATA
    ========================= */

    totalStorage,
    cpuModel,
    totalMemoryGB,
    computerName,
    localIp,
    publicIp,
    macAddress,
    infoFiles,

    /* =========================
       NEW SYSTEM INFO
    ========================= */

    osType: osInfo.platform,
    osVersion: `${osInfo.distro} ${osInfo.release}`,
    osArch: osInfo.arch,

    uptime: time.uptime,

    loggedUser: os.userInfo().username,

    deviceManufacturer: manufacturer,
    deviceModel: model,
    deviceSerial: serial,
  };
}

/* =========================
   NETWORK INFO (STATIC)
========================= */

function getNetworkInfo() {
  const interfaces = os.networkInterfaces();

  for (const name of Object.keys(interfaces)) {
    const netInterface = interfaces[name];
    if (!netInterface) continue;

    for (const net of netInterface) {
      if (net.family === "IPv4" && !net.internal) {
        return {
          localIp: net.address,
          macAddress: net.mac,
        };
      }
    }
  }

  return {
    localIp: "N/A",
    macAddress: "N/A",
  };
}

/* =========================
   PUBLIC IP (SAFE + CACHED)
========================= */

let cachedPublicIp: string | null = null;

async function getPublicIp(): Promise<string> {
  if (cachedPublicIp) return cachedPublicIp;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3000);

    const res = await fetch("https://api.ipify.org", {
      signal: controller.signal,
    });

    clearTimeout(timeout);

    cachedPublicIp = await res.text();
    return cachedPublicIp;
  } catch {
    return "N/A";
  }
}

async function getFullNetworkData() {
  const { localIp, macAddress } = getNetworkInfo();
  const publicIp = await getPublicIp();

  return {
    localIp,
    macAddress,
    publicIp,
  };
}

/* =========================
   INFO FILES
========================= */

function getInfoFileData() {
  let infoPath: string;

  if (process.platform === "win32") {
    infoPath = "C:/info";
  } else {
    infoPath = path.join(os.homedir(), "info");
  }

  if (!fs.existsSync(infoPath)) {
    return {
      rcTag: "",
      department: "",
      assignedLocationBuilding: "",
      assignedLocationRoom: "",
      localAccount: "",
      ownerFirstName: "",
      ownerLastName: "",
      ownerEmail: "",
      usageType: "",
      yearModel: "",
    };
  }

  const readFile = (fileName: string) => {
    const fullPath = path.join(infoPath, fileName);
    if (!fs.existsSync(fullPath)) return "";
    return fs.readFileSync(fullPath, "utf-8").trim();
  };

  return {
    rcTag: readFile("RCTag.txt"),
    department: readFile("Department.txt"),
    assignedLocationBuilding: readFile("AssignedLocationBuilding.txt"),
    assignedLocationRoom: readFile("AssignedLocationRoom.txt"),
    localAccount: readFile("LocalAccount.txt"),
    ownerFirstName: readFile("OwnerFirstName.txt"),
    ownerLastName: readFile("OwnerLastName.txt"),
    ownerEmail: readFile("OwnerEmail.txt"),
    usageType: readFile("UsageType.txt"),
    yearModel: readFile("YearModel.txt"),
  };
}

export function buildFullItReport(data: any, stats: any) {
  return `
==============================
RC SYSTEM FULL DIAGNOSTIC REPORT
==============================

--- SYSTEM INFO ---
Computer Name: ${data.computerName}
Logged User: ${data.loggedUser}
RCTag: ${data.infoFiles?.rcTag}
Department: ${data.infoFiles?.department}
Usage Type: ${data.infoFiles?.usageType}

OS Type: ${data.osType}
OS Version: ${data.osVersion}
Architecture: ${data.osArch}
Uptime: ${Math.floor(data.uptime / 60)} minutes

Device Manufacturer: ${data.deviceManufacturer}
Device Model: ${data.deviceModel}
Device Serial: ${data.deviceSerial}

--- NETWORK ---
Local IP: ${data.localIp}
MAC Address: ${data.macAddress}
Public IP: ${data.publicIp}

--- STORAGE ---
Total Storage: ${data.totalStorage} GB

--- CPU ---
Model: ${data.cpuModel}

--- MEMORY ---
Total Memory: ${data.totalMemoryGB} GB

--- LIVE STATS (CURRENT SNAPSHOT) ---
CPU Usage: ${Math.round(stats.cpuUsage * 100)}%
RAM Usage: ${Math.round(stats.ramUsage * 100)}%
Storage Usage: ${Math.round(stats.storageUsage * 100)}%

Network Up: ${stats.netUp} B/s
Network Down: ${stats.netDown} B/s

==============================
END REPORT
==============================
`;
}
